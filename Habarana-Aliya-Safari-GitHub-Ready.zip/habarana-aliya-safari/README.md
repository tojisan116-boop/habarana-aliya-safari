# Habarana Aliya Safari & Village Tours

GitHub Pages-ready static website.

## Before publishing
Replace `YOUR-GITHUB-USERNAME` and `YOUR-REPOSITORY` in:
- every HTML canonical URL
- `robots.txt`
- `sitemap.xml`
- the JSON-LD URL in `index.html`

Keep these supplied images in `images/`:
logo.png, hero.jpg, elephant.jpg, gallery1.jpg, gallery2.jpg, gallery3.jpg, gallery4.jpg, gallery5.jpg, gallery6.jpg, village.jpg, kaudulla.jpg, minneriya.jpg, hurulu.jpg, kalawwewa.jpg

Optional missing assets requested by the original brief are listed in `images/UPLOAD_THESE_IMAGES.txt`.

The exact business location is intentionally not hard-coded because it was not independently verified. The Maps button searches Habarana generally rather than claiming a precise business pin.
