
const WHATSAPP_NUMBER = "94764806045";
const FACEBOOK_URL = "https://www.facebook.com/share/1Sw6TGjMYz/";

const enquiryDefaults = {
  tour: "",
  date: "",
  guests: "",
  pickup: "",
  name: "",
  phone: "",
  message: ""
};

function whatsappUrl(message){
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

function buildEnquiryMessage(data = {}){
  const d = {...enquiryDefaults, ...data};
  return `Hello Habarana Aliya Safari & Village Tours,

I would like to enquire about a safari or village experience.

Name: ${d.name || "Not provided"}
Tour: ${d.tour || "Not selected"}
Preferred date: ${d.date || "Not provided"}
Number of guests: ${d.guests || "Not provided"}
Pickup location: ${d.pickup || "Not provided"}
Phone / WhatsApp: ${d.phone || "Not provided"}
Message: ${d.message || "Not provided"}

Thank you.`;
}

function setupWhatsAppLinks(){
  document.querySelectorAll("[data-whatsapp]").forEach(link => {
    link.href = whatsappUrl(link.dataset.whatsapp || "Hello Habarana Aliya Safari & Village Tours, I would like to make an enquiry.");
    link.target = "_blank";
    link.rel = "noopener noreferrer";
  });
  document.querySelectorAll("[data-whatsapp-tour]").forEach(link => {
    const tour = link.dataset.whatsappTour;
    link.href = whatsappUrl(buildEnquiryMessage({tour}));
    link.target = "_blank";
    link.rel = "noopener noreferrer";
  });
}

function setupHeader(){
  const header = document.querySelector(".site-header");
  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".nav-links");
  if(!header) return;

  const onScroll = () => header.classList.toggle("scrolled", window.scrollY > 30);
  onScroll();
  window.addEventListener("scroll", onScroll, {passive:true});

  toggle?.addEventListener("click", () => {
    const open = document.body.classList.toggle("nav-open");
    toggle.setAttribute("aria-expanded", String(open));
    toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  });

  nav?.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
    document.body.classList.remove("nav-open");
    toggle?.setAttribute("aria-expanded","false");
  }));

  document.addEventListener("keydown", e => {
    if(e.key === "Escape") document.body.classList.remove("nav-open");
  });
}

function setupEnquiryForms(){
  document.querySelectorAll("[data-enquiry-form]").forEach(form => {
    form.addEventListener("submit", e => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(form).entries());
      const message = buildEnquiryMessage(data);
      window.open(whatsappUrl(message), "_blank", "noopener,noreferrer");
    });
  });
}

function setupReveal(){
  const items = document.querySelectorAll(".reveal");
  if(!("IntersectionObserver" in window)){
    items.forEach(i=>i.classList.add("visible"));
    return;
  }
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if(entry.isIntersecting){
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, {threshold:.12});
  items.forEach(i=>observer.observe(i));
}

function setupFaq(){
  document.querySelectorAll(".faq-item").forEach(item => {
    const button = item.querySelector(".faq-question");
    button?.addEventListener("click", () => {
      const isOpen = item.classList.contains("open");
      document.querySelectorAll(".faq-item.open").forEach(other => {
        other.classList.remove("open");
        other.querySelector(".faq-question")?.setAttribute("aria-expanded","false");
      });
      if(!isOpen){
        item.classList.add("open");
        button.setAttribute("aria-expanded","true");
      }
    });
  });
}

function setupGallery(){
  const items = [...document.querySelectorAll(".gallery-item")];
  const buttons = [...document.querySelectorAll("[data-filter]")];
  const lightbox = document.querySelector(".lightbox");
  if(!items.length || !lightbox) return;

  let visibleItems = items;
  let current = 0;

  const render = () => {
    const filter = document.querySelector("[data-filter].active")?.dataset.filter || "all";
    visibleItems = items.filter(item => filter === "all" || item.dataset.category.split(" ").includes(filter));
    items.forEach(item => item.classList.toggle("hidden", !visibleItems.includes(item)));
  };

  buttons.forEach(btn => btn.addEventListener("click", () => {
    buttons.forEach(b=>b.classList.remove("active"));
    btn.classList.add("active");
    render();
  }));

  const image = lightbox.querySelector("img");
  const caption = lightbox.querySelector(".lightbox-caption");

  const show = index => {
    if(!visibleItems.length) return;
    current = (index + visibleItems.length) % visibleItems.length;
    const source = visibleItems[current].querySelector("img");
    image.src = source.currentSrc || source.src;
    image.alt = source.alt;
    caption.textContent = source.alt;
    lightbox.classList.add("open");
    lightbox.setAttribute("aria-hidden","false");
    document.body.classList.add("nav-open");
  };

  const close = () => {
    lightbox.classList.remove("open");
    lightbox.setAttribute("aria-hidden","true");
    document.body.classList.remove("nav-open");
  };

  items.forEach(item => item.addEventListener("click", () => show(visibleItems.indexOf(item))));
  lightbox.querySelector(".lightbox-close")?.addEventListener("click", close);
  lightbox.querySelector(".lightbox-prev")?.addEventListener("click", () => show(current - 1));
  lightbox.querySelector(".lightbox-next")?.addEventListener("click", () => show(current + 1));
  lightbox.addEventListener("click", e => { if(e.target === lightbox) close(); });

  document.addEventListener("keydown", e => {
    if(!lightbox.classList.contains("open")) return;
    if(e.key === "Escape") close();
    if(e.key === "ArrowLeft") show(current - 1);
    if(e.key === "ArrowRight") show(current + 1);
  });

  render();
}

const translations = {
  en: {
    home:"Home", safaris:"Safaris", village:"Village Tours", destinations:"Destinations",
    gallery:"Gallery", about:"About", contact:"Contact", book:"Book Now",
    explore:"Explore Tours", request:"Request a Safari", call:"Call", whatsapp:"WhatsApp",
    "feel-freshness":"Feel the freshness"
  },
  si: {
    home:"මුල් පිටුව", safaris:"සෆාරි", village:"ගම්මාන සංචාර", destinations:"ගමනාන්ත",
    gallery:"ඡායාරූප", about:"අප ගැන", contact:"සම්බන්ධ වන්න", book:"දැන් වෙන්කරන්න",
    explore:"සංචාර බලන්න", request:"සෆාරියක් විමසන්න", call:"අමතන්න", whatsapp:"WhatsApp",
    "feel-freshness":"නැවුම් බව විඳින්න"
  }
};

function setupLanguage(){
  const stored = localStorage.getItem("hali-lang") || "en";
  applyLanguage(stored);
  document.querySelectorAll("[data-lang]").forEach(btn => {
    btn.addEventListener("click", () => {
      const lang = btn.dataset.lang;
      localStorage.setItem("hali-lang", lang);
      applyLanguage(lang);
    });
  });
}

function applyLanguage(lang){
  document.documentElement.lang = lang === "si" ? "si" : "en";
  const dict = translations[lang] || translations.en;
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.dataset.i18n;
    if(dict[key]) el.textContent = dict[key];
  });
  document.querySelectorAll("[data-lang]").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.lang === lang);
  });
}

function setupYear(){
  document.querySelectorAll("[data-year]").forEach(el => el.textContent = new Date().getFullYear());
}

document.addEventListener("DOMContentLoaded", () => {
  setupHeader();
  setupWhatsAppLinks();
  setupEnquiryForms();
  setupReveal();
  setupFaq();
  setupGallery();
  setupLanguage();
  setupYear();
});
